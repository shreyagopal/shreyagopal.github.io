---
title:  "Get started with Google Colaboratory (CNN in Tensorflow)"
date:   2018-03-27 17:00:00
categories: [google-colab]
tags: [google-colab]

---

Google Colab is a free cloud service and now it supports free GPU! You can now improve your Python programming language coding skills.This is a small tutorial on how you can use Google Colaboratory's GPU free for training a neural network or CNN for free.


## To view the video
* [Click here](https://youtu.be/4BVpzY6prJ0){:target="_blank"}
* Click on the image below

[![What does P-Value mean in Regression?](http://img.youtube.com/vi/4BVpzY6prJ0/0.jpg)](http://www.youtube.com/watch?v=4BVpzY6prJ0){:target="_blank"}

### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
