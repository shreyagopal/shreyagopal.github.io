---
title:  "Delete Specific Websites from Google Chrome History using Python"
date:   2019-07-07 17:00:00
categories: [python, delete-chrome-history-python]
tags: [python, delete-chrome-history-python]

---

Wouldn't it be nice to selectively delete Google Chrome History based on Websites. In this video, I have created a small Python script which deletes all instances of GitHub.com from the browser history ! I hope you find it useful 🙂

## To view the video
* [Click here](https://youtu.be/bBFw9ArnTpA){:target="_blank"}
* Click on the image below

[![Delete Specific Websites from Google Chrome History using Python](http://img.youtube.com/vi/bBFw9ArnTpA/0.jpg)](http://www.youtube.com/watch?v=bBFw9ArnTpA){:target="_blank"}

### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
