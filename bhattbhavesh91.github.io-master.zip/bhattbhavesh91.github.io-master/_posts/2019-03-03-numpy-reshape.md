---
title:  "What exactly is reshape(-1,1) in Numpy & Pandas (Python)?"
date:   2019-03-03 17:00:00
categories: [numpy, reshape]
tags: [numpy, reshape]

---

In this simple demo, I plan to demystify the confusion surrounding reshape (-1,1) function. Hope it is helpful.


## To view the video
* [Click here](https://youtu.be/3wi0lJPfLUY){:target="_blank"}
* Click on the image below

[![What exactly is reshape(-1,1) in Numpy & Pandas (Python)?](http://img.youtube.com/vi/3wi0lJPfLUY/0.jpg)](http://www.youtube.com/watch?v=3wi0lJPfLUY){:target="_blank"}

### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
