---
title: "I got recognized as a 40 Under 40 Data Scientist in India!"
date: 2020-01-23 15:30:00
categories: [data-science]
tags: [data-science]
description: I was recognized by Analytics India Magazine as a 40 under 40 Data Scientists at Machine Learning Developer Summit 2020 (MLDS2020) in India.
---

It's the year 2020! If we add 20 with 20 we get 40.

I am super excited to be recognized as one of the 40 under 40 Data Scientists at Machine Learning Developers Summit 2020 (MLDS2020) in Bengaluru, India.

&nbsp;  
![40Under40Image](/assets/images/40Under40Bhavesh.JPG)  
<!--**Image Credits: Courtesy Google Developer Experts**-->
&nbsp;  


### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
