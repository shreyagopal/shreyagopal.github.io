---
title:  "vLookup using Python & Pandas"
date:   2018-02-10 17:00:00
categories: [vLookup]
tags: [vLookup]

---

This is a small tutorial on how to use Pandas for doing a simple vLookup.


## To view the video
* [Click here](https://youtu.be/5hHW-g0uSUA){:target="_blank"}
* Click on the image below

[![Simplest example of Decision Tree](http://img.youtube.com/vi/5hHW-g0uSUA/0.jpg)](http://www.youtube.com/watch?v=5hHW-g0uSUA){:target="_blank"}


### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>

