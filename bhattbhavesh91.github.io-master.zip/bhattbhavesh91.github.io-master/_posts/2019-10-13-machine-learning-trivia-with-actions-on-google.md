---
title:  "Machine Learning Trivia With Actions On Google"
date:   2019-10-13 17:00:00
categories: [machine-learning, actions-on-google, google-assistant]
tags: [machine-learning, actions-on-google, google-assistant]
description: I created a simple decision tree trivia or quiz using Actions on Google. Using access it by saying - OK Google, Ask Decision Tree Trivia.
---

Wouldn't it be nice if 10 minutes before a data science interview, Google Assistant asks you all MCQ's about a concept like Decision Tree.

While experimenting with "Actions on Google", I created a small Trivia on Decision Trees.

Do check it out by opening Google Assistant & saying "Ask Decision Tree Trivia" & the MCQ's will start. 


# How I created my first app on action on Google:-
  - Create a new project
  - Choose template option
  - Choose your any quiz/trivia option
  - Name Your trivia and edit the sheet with quiz
  - Test the app
  - Add details like privacy policy, about your quiz, logo etc
  - Submit for review

This was just an experiment with 15 questions that I created. Based on your feedback, I would love to create more such trivia's.

Feel free to drop in your feedback & share it with your network.  
<a href="https://assistant.google.com/services/a/uid/000000ffc6b3bce6?hl=en&source=web&source=web">Link to the Google Assistant Action</a>

### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
