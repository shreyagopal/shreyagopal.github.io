---
title:  "TensorFlow 2.0 - Introductory Tutorial"
date:   2019-04-17 17:00:00
categories: [tensorflow, neural-network]
tags: [tensorflow, neural-network]

---

TensorFlow 2.0 is here! Let's take a look at a simple tutorial on the basics of TensorFlow.


## To view the video
* [Click here](https://youtu.be/wN4j0CpLp58){:target="_blank"}
* Click on the image below

[![TensorFlow 2.0 - Introductory Tutorial](http://img.youtube.com/vi/wN4j0CpLp58/0.jpg)](http://www.youtube.com/watch?v=wN4j0CpLp58){:target="_blank"}

### Want to know more about me?
## Follow Me
<a href="https://twitter.com/_bhaveshbhatt" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/tw.png" width="30"></a>
<a href="https://www.youtube.com/bhaveshbhatt8791/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/ytb.png" width="30"></a>
<a href="https://www.youtube.com/PythonTricks/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/python_logo.png" width="30"></a>
<a href="https://github.com/bhattbhavesh91" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/gthb.png" width="30"></a>
<a href="https://www.linkedin.com/in/bhattbhavesh91/" target="_blank"><img class="ai-subscribed-social-icon" src="/assets/images/lnkdn.png" width="30"></a>
